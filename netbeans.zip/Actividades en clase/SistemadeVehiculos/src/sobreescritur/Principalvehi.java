/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sobreescritur;

/**
 *
 * @author Constanza
 */
public class Principalvehi {
    public static void main(String[] args){
        Coche coche= new Coche();
        Motocicleta motocicleta= new Motocicleta();
        Bicicleta bicicleta= new Bicicleta();
        coche.mover();   
        motocicleta.mover();
        bicicleta.mover();
    }
    
}
