/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Animal;

/**
 *
 * @author Constanza
 */
public class Perro extends Animal{
    
    /**
     *
     */
    @Override
    public void comer(){
        System.out.println("Estoy consumiendo comida para perros");
    }
    
}
