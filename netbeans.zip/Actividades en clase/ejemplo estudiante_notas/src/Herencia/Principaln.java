/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencia;

/**
 *
 * @author Constanza
 */
public class Principaln {
    public static void main(String[]ags){
        Estudiante estudiante1=new Estudiante(113,4.5f,"Andres","Ruiz",29);
        estudiante1.mostrarDatos();
            
    }
    
}
